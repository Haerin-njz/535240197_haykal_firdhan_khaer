module.exports = [
"[project]/.next-internal/server/app/kpop-list/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_kpop-list_page_actions_0be6ffb0.js.map