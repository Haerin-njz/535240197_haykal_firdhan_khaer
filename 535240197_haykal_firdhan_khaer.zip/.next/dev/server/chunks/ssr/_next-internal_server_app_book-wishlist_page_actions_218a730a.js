module.exports = [
"[project]/.next-internal/server/app/book-wishlist/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_book-wishlist_page_actions_218a730a.js.map