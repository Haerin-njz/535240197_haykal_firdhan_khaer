(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_bootstrap_dist_css_bootstrap_min_9b8a96a4.css"
],
    source: "dynamic"
});
